package com.solmark;

import java.util.StringTokenizer;
import javassist.ClassPool;

import org.gotti.wurmunlimited.modloader.classhooks.HookManager;
import org.gotti.wurmunlimited.modloader.interfaces.Initable;
import org.gotti.wurmunlimited.modloader.interfaces.PlayerMessageListener;
import org.gotti.wurmunlimited.modloader.interfaces.PreInitable;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;

import com.wurmonline.server.MessageServer;
import com.wurmonline.server.Players;
import com.wurmonline.server.Server;
import com.wurmonline.server.creatures.Communicator;
import com.wurmonline.server.economy.Change;
import com.wurmonline.server.economy.Economy;
import com.wurmonline.server.players.Player;
import com.wurmonline.server.players.Titles.Title;

import javassist.CtClass;

public class BalanceMod implements WurmServerMod, PlayerMessageListener {

    @Override
    public void preInit() {
    }

    @Override
    public boolean onPlayerMessage(Communicator chat,String message) {
        if (message.startsWith("/balance")) {
            long playerMoney = chat.getPlayer().getMoney();
            Change playerBalance = Economy.getEconomy().getChangeFor(playerMoney);
            handleSlashMessageBalance(chat, playerBalance);
            return true;
        }
        return false;
    }

    public static void handleSlashMessageBalance(Communicator chat, Change playerBalance) {
        chat.sendNormalServerMessage("Your current bank balance is " + playerBalance.getChangeString());
    }
}
